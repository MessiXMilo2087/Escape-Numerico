##############################################
             ESCAPE NUMÉRICO
##############################################

Creado por: MessiXMilo2087

Descripción:
-------------
Escape Numérico es un juego experimental donde 
debes resolver acertijos numéricos para salir 
de una prisión digital. Pon a prueba tu mente 
y demuestra tu habilidad para encontrar el 
número correcto antes de quedarte sin tiempo.

Controles:
----------
- Teclado: Escribe tus respuestas numéricas.
- Enter: Enviar respuesta.

Modo de juego:
--------------
1. El juego genera un número secreto.
2. Tendrás varios intentos para adivinarlo.
3. El sistema te dirá si el número es más alto
   o más bajo.
4. Si lo logras, ¡escapas! Si fallas, quedas 
   atrapado en la simulación.

Requisitos:
-----------
- Python 3.11 o superior.
- No necesita instalación extra.

Cómo jugar:
-----------
1. Abre una terminal o PowerShell.
2. Escribe: python escape_numerico.py
3. ¡Disfruta!

Contacto:
---------
GitHub: https://github.com/MessiXMilo2087
GameJolt: https://gamejolt.com/@MessiXMilo2087

##############################################
