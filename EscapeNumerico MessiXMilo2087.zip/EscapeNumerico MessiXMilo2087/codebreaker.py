import random

print("🔢🚪 Bienvenido a ESCAPE NUMÉRICO 🚪🔢")
print("Adivina el código de 3 dígitos para escapar de la habitación.")
print("Pista: Los dígitos son del 0 al 9.")

# Generar código secreto
codigo = [str(random.randint(0,9)) for _ in range(3)]

intentos = 0

while True:
    intento = input("Ingresa tu código (3 dígitos): ")

    if len(intento) != 3 or not intento.isdigit():
        print("Código inválido, deben ser 3 números.")
        continue

    intentos += 1

    if list(intento) == codigo:
        print(f"🎉 ¡Correcto! Escapaste en {intentos} intentos.")
        break

    # Dar pistas
    for i in range(3):
        if intento[i] == codigo[i]:
            print(f"Dígito {i+1}: 🔒 Exacto")
        elif intento[i] in codigo:
            print(f"Dígito {i+1}: 🔄 Número correcto, lugar equivocado")
        else:
            print(f"Dígito {i+1}: ❌ No está en el código")

    print("🔁 Intenta de nuevo.\n")
